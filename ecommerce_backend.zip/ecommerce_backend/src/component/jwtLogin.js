const { SignJWT, jwtVerify, generateSecret } = require('jose');

// Secret key for signing (use a secure, random key in production)
let secret;

// Simulated "user database"
const fakeUser = {
  id: '123',
  email: 'user@example.com',
  password: 'securepassword' // In real apps, store a hashed password!
};

// Generate secret once (or load from env)
async function initSecret() {
  if (!secret) {
    secret = await generateSecret('HS256');
  }
}

// Login: generate JWT if credentials are correct
async function login(email, password) {
  await initSecret();

  if (email === fakeUser.email && password === fakeUser.password) {
    const jwt = await new SignJWT({ userId: fakeUser.id, email })
      .setProtectedHeader({ alg: 'HS256' })
      .setIssuedAt()
      .setExpirationTime('2h') // Expires in 2 hours
      .sign(secret);
    return jwt;
  } else {
    throw new Error('Invalid email or password');
  }
}

// Verify JWT (e.g., for protected routes)
async function verify(token) {
  await initSecret();

  try {
    const { payload } = await jwtVerify(token, secret);
    return payload;
  } catch (err) {
    throw new Error('Invalid or expired token');
  }
}

// Example usage
(async () => {
  try {
    const token = await login('user@example.com', 'securepassword');
    console.log('✅ JWT:', token);

    const payload = await verify(token);
    console.log('🔓 Verified Payload:', payload);
  } catch (err) {
    console.error('❌ Error:', err.message);
  }
})();

async function jwtLogin(){
    (async () => {
        try {
            const token = await login('user@example.com', 'securepassword');
            console.log('✅ JWT:', token);

            const payload = await verify(token);
            console.log('🔓 Verified Payload:', payload);
        } catch (err) {
            console.error('❌ Error:', err.message);
        }
    })();
}
