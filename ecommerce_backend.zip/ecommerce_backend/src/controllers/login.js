const { AppDataSource } = require('./../data-source');
// import is not working here, hence used require method

exports.login = async (req, res) =>{
    
    let { username, password } = req.body;
    try {
        let sqlQuery = `SELECT * FROM user WHERE userName = '${username}' AND password = '${password}';`;
        const results = await AppDataSource.manager.query(sqlQuery);
        if(results.length != 0){
            console.log("User Found");
            res.send({
                "success" : 1,
                "status"  : 200,    
                "message" : "User Found, Login Successful",
                "userName": results[0].userName ? results[0].userName : ""
            });
            // console.log(results[0].userName);            
        } else {
            console.log("User not found");
            res.send({
                "success" : 0,
                "status"  : 200,
                "message" : "User Not Found"
            });
        }
    } catch (e){
        console.log("Error : " , e);
    }
    
}