const {AppDataSource} = require("./../data-source");
const { User } = require("./../entity/User");

exports.register = async (req, res) => {
    console.log("Register User Details");
    if(req.body){
        const userFound = await AppDataSource.manager.findBy(User, {
            email: req.body.email,
            contactNumber: req.body.contactNumber
        });
        if(userFound.length !== 0){
            console.log("User details found");
            res.send({
                "status"  : 200,
                "message" : "User Not Inserted"
            });
        } else {
            const user = await AppDataSource.manager.insert(User, req.body)
            res.send({
                "status"  : 200,
                "message" : "User Inserted"
            });
            console.log("User details inserted");
        }
    }
}