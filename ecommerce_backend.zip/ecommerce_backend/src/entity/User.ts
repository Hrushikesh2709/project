import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn } from "typeorm"

@Entity()
export class User {

    @PrimaryGeneratedColumn()
    id: number

    @Column({ 
        nullable: true
    })
    salutation: string

    @Column({ 
        nullable: true
    })
    firstName: string

    @Column({ 
        nullable: true
    })
    lastName: string

    @Column({ 
        nullable: true
    })
    age: number

    @Column({ 
        type: "bigint",
        nullable: true
    })
    contactNumber: number

    @Column({ 
        nullable: true
    })
    email: string

    @Column({ 
        nullable: true
    })
    userName: string 
    
    @Column({ 
        nullable: true
    })
    password:string 
    
    @Column({ 
        nullable: true
    })
    notifyEmail: string
    
    @Column({ 
        nullable: true
    })
    gst: string 
    
    @Column({ 
        nullable: true
    })
    coupon: string
    
    @Column({ 
        nullable: true
    })
    language: string
    
    @Column({ 
        nullable: true
    })
    paymentOptionId: number
    
    @Column({ 
        nullable: true
    })
    userAddressId: number
    
    @Column({ 
        nullable: true
    })
    isActive: number
    
    @Column({ 
        type: "datetime",
        default: () => "NOW()"
    })
    dateAdded: String
    
    @Column({ 
        type: "datetime",
        default: () => "NOW()",
        onUpdate: "NOW()"
    })
    dateModified: String

}