import { AppDataSource } from "./data-source"
import { Like } from "typeorm";
import { User } from "./entity/User"
import * as jose from "jose";
const express = require("express");
const app = express();
const cors = require("cors");

app.use(cors());
app.use(express.json());

app.get("/", (req, res)=>{
    let obj = {
        "status" : 200,
        "message": "Connection Successful"
    };
    res.send(obj);
});

app.post("/login", async (req, res)=>{
    let { username, password } = req.body;
    try {
        let sqlQuery = `SELECT * FROM user WHERE userName = '${username}' AND password = '${password}';`;
        const results = await AppDataSource.manager.query(sqlQuery);
        if(results.length != 0){
            console.log("User Found");
            res.send({
                "success" : 1,
                "status"  : 200,    
                "message" : "User Found, Login Successful"
            });
        } else {
            console.log("User not found");
            res.send({
                "success" : 0,
                "status"  : 200,
                "message" : "User Not Found"
            });
        }
    } catch (e){
        console.log("Error : " , e);
    }
})

app.post("/register", async (req, res)=>{
    console.log("Register User Details");
    if(req.body){
        const userFound = await AppDataSource.manager.findBy(User, {
            email: req.body.email,
            contactNumber: req.body.contactNumber
        });
        if(userFound){
            console.log(userFound);
            res.send({
                "status"  : 200,
                "message" : "User Not Inserted"
            });
        } else {
            const user = await AppDataSource.manager.insert(User, req.body)
            res.send({
                "status"  : 200,
                "message" : "User Inserted"
            });
        }
    }
});

// Username availability checking
app.post("/validateUserName", async (req, res)=>{
    // const userFound = await AppDataSource.manager.findBy(User, {
    //     firstName: Like("%rushi%")
    // });
    const userFound = await AppDataSource.manager.findBy(User, {
        userName: req.body.userName
    });
    console.log("Found User: ", userFound);
});

app.listen(3500, ()=>{
    console.log("App is listening on port 3500");
})

AppDataSource.initialize().then(async() => {
    // const user = await AppDataSource.manager.findOneBy(User, {
    //     id: 1,
    // });
    console.info("Database connection successful");
    // user.firstName = "Rushikesh"
    // await AppDataSource.manager.save(user)
    // console.log("Updated user with id: " + user.id)

    // console.log("Loading users from the database...")
    // const users = await AppDataSource.manager.find(User)
    // console.log("Loaded users: ", users)
}).catch(error=>console.log(error))