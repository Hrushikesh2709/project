import { AppDataSource } from "./data-source"
import { User } from "./entity/User"
import * as jose from "jose";
import { SignJWT, jwtVerify, generateSecret } from 'jose';
// import jwtLogin from "./component/jwtLogin";
const express = require("express");
const app = express();
const cors = require("cors");

app.use(cors());
app.use(express.json());

app.get("/", (req, res)=>{
    let obj = {
        "status" : 200,
        "message": "Connection Successful"
    };
    res.send(obj);
});

// jwtLogin();

app.post("/login", (req, res)=>{
    let { username, password } = req.body;
    console.log("1. Username: ", username);
    console.log("2. Password: ", password);
    
    res.send({
        "status"  : 200,
        "message" : "Data Saved"
    });
})

app.listen(3500, ()=>{
    console.log("App is listening on port 3500");
})

AppDataSource.initialize().then(async() => {
    const user = await AppDataSource.manager.findOneBy(User, {
        id: 1,
    })
    user.firstName = "Rushikesh"
    await AppDataSource.manager.save(user)
    console.log("Updated user with id: " + user.id)

    console.log("Loading users from the database...")
    const users = await AppDataSource.manager.find(User)
    console.log("Loaded users: ", users)
}).catch(error=>console.log(error));

// Secret key for signing (use a secure, random key in production)
let secret;

// Simulated "user database"
const fakeUser = {
  id: '123',
  email: 'user@example.com',
  password: 'securepassword' // In real apps, store a hashed password!
};

// Generate secret once (or load from env)
async function initSecret() {
  if (!secret) {
    secret = await generateSecret('HS256');
  }
}

// Login: generate JWT if credentials are correct
async function login(email, password) {
  await initSecret();

  if (email === fakeUser.email && password === fakeUser.password) {
    const jwt = await new SignJWT({ userId: fakeUser.id, email })
      .setProtectedHeader({ alg: 'HS256' })
      .setIssuedAt()
      .setExpirationTime('2h') // Expires in 2 hours
      .sign(secret);
    return jwt;
  } else {
    throw new Error('Invalid email or password');
  }
}

// Verify JWT (e.g., for protected routes)
async function verify(token) {
  await initSecret();

  try {
    const { payload } = await jwtVerify(token, secret);
    return payload;
  } catch (err) {
    throw new Error('Invalid or expired token');
  }
}

// Example usage
(async () => {
  try {
    const token = await login('user@example.com', 'securepassword');
    console.log('✅ JWT:', token);

    const payload = await verify(token);
    console.log('🔓 Verified Payload:', payload);
  } catch (err) {
    console.error('❌ Error:', err.message);
  }
})();


// AppDataSource.initialize().then(async () => {

//     console.log("Inserting a new user into the database...")
//     const user = new User()
//     user.salutation = "Mr"
//     user.firstName = "Rushikesh"
//     user.lastName = "Waghunde"
//     user.age = 25
//     user.contactNumber = 7058177585
//     user.email = "rushikeshwaghunde@gmail.com"
//     user.userName = "rushikesh"
//     user.password = "rushikesh"
//     user.notifyEmail = "rushikeshwaghunde@gmail.com"
//     user.gst = "123456789012345"
//     user.coupon = "COUPON"
//     user.language = "ENGLISH"
//     user.paymentOptionId = 1
//     user.userAddressId = 1
//     user.isActive = 1
//     // user.dateAdded = ""
//     // user.dateModified = ""

//     await AppDataSource.manager.save(user)
//     console.log("Saved a new user with id: " + user.id)

//     console.log("Loading users from the database...")
//     const users = await AppDataSource.manager.find(User)
//     console.log("Loaded users: ", users)

//     console.log("Here you can setup and run express / fastify / any other framework.")

// }).catch(error => console.log(error))
