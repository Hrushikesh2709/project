import { AppDataSource } from "./data-source"
import { Like } from "typeorm";
import { User } from "./entity/User"
import * as jose from "jose";

const express = require("express");
const app = express();
const cors = require("cors");

const user = require("./routes/user");

app.use(cors());
app.use(express.json());

app.get("/", (req, res)=>{
    let obj = {
        "status" : 200,
        "message": "Connection Successful"
    };
    res.send(obj);
});

app.use("/user", user); 

// Username availability checking
app.post("/validateUserName", async (req, res)=>{
    const userFound = await AppDataSource.manager.findBy(User, {
        userName: req.body.userName
    });
    console.log("Found User: ", userFound);
});

app.listen(3500, ()=>{
    console.log("App is listening on port 3500");
})

AppDataSource.initialize().then(async() => {
    
    console.info("Database connection successful");
    
}).catch(error=>console.log(error))