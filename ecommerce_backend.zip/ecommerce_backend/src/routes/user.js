const express = require("express");
const router = express.Router();
const handleLogin = require("../controllers/login");
const handleRegister = require("../controllers/register");

router.post("/login", handleLogin.login);
router.post("/register", handleRegister.register);

module.exports = router;