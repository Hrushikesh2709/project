import { Backdrop, Typography } from "@mui/material";
import CancelIcon from '@mui/icons-material/Cancel';

function CancelAlert({open, onClose, message = "Failed"}){
    return (
        <Backdrop open={open} onClick={onClose} sx={{color:'#fff', zIndex:(theme) => theme.zIndex.drawer + 1, flexDirection: 'column', cursor: onClose ? 'pointer': 'default'}}>
            <CancelIcon sx={{fontSize: 80, color:'#f44336', mb:2}}/>
            <Typography variant="h6">{message}</Typography>
        </Backdrop>
    );
}

export default CancelAlert;