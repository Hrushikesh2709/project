import React from "react";

async function Handler({request}){
    let data = await request.formData();
    let username = data.get("username");
    let password = data.get("password");
    return (<div>
        <p></p>
    </div>);
}