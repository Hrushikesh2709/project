import * as React from 'react';
import Alert from '@mui/material/Alert';
import Stack from '@mui/material/Stack';

function OutlinedAlert(){
  return (
    <Stack autoHideDuration={5000} sx={{ width: '100%' }} spacing={2}>
      <Alert autoHideDuration={5000} className="!mx-5 !mt-5" variant="outlined" severity="success">
        This is an outlined success Alert.
      </Alert>
      <Alert className="!mx-5 !mt-5" variant="outlined" severity="success">
        This is an outlined success Alert.
      </Alert>
    </Stack>
  );
}

export default OutlinedAlert;