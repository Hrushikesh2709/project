import { Backdrop, Typography } from "@mui/material";
import CheckCircleIcon from '@mui/icons-material/CheckCircle';

function SuccessAlert({open, onClose, message = "Success"}){
    return (
        <Backdrop open={open} onClick={onClose} sx={{color:'#fff', zIndex:(theme) => theme.zIndex.drawer + 1, flexDirection: 'column', cursor: onClose ? 'pointer': 'default'}}>
            <CheckCircleIcon sx={{fontSize: 80, color:'lightgreen', mb:2}}/>
            <Typography variant="h6">{message}</Typography>
        </Backdrop>
    );
}

export default SuccessAlert;