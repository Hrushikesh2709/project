import { Button } from "@mui/material";
import { useState, useEffect } from "react";

function ToggleDarkMode(){
    const [darkMode, setDarkMode] = useState(false);
    useEffect(()=>{
        const root = window.document.documentElement;
        if(darkMode){
            root.classList.add("dark");
        } else {
            root.classList.remove("dark");
        }
    },[darkMode]);

    return (
        <Button 
            onClick={()=>setDarkMode(!darkMode)}
            className="px-4 py-2 bg-gray-200 dark:bg-gray-800 dark:text-white rounded"
        >
            Toggle Dark Mode
        </Button>
    )
}

export default ToggleDarkMode;