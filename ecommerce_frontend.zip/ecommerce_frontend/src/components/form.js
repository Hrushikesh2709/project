// main.jsx or index.jsx
import React from "react";
import ReactDOM from "react-dom/client";
import {
  createBrowserRouter,
  RouterProvider,
  Form,
  redirect,
} from "react-router-dom";

function FormPage() {
  return (
    <div>
      <h2>Simple Form</h2>
      <Form method="post">
        <label>
          Name:
          <input type="text" name="username" />
        </label>
        <button type="submit">Submit</button>
      </Form>
    </div>
  );
}

// Action to handle form POST
async function formAction({ request }) {
  const formData = await request.formData();
  const username = formData.get("username");
  console.log("Form submitted with username:", username);

  // Normally you'd process or save the data here
  return redirect(`/success?name=${username}`);
}

function SuccessPage({ location }) {
  const params = new URLSearchParams(location?.search);
  const name = params.get("name");
  return <h3>Form submitted! Hello, {name}</h3>;
}

// Router config
const router = createBrowserRouter([
  {
    path: "/",
    element: <FormPage />,
    action: formAction,
  },
  {
    path: "/success",
    element: <SuccessPage />,
  },
]);

ReactDOM.createRoot(document.getElementById("root")).render(
  <RouterProvider router={router} />
);
