import React from 'react';
import ReactDOM from 'react-dom/client';
// import { BrowserRouter, Routes, Route } from 'react-router';
import './css/index.css';
import Login from './pages/Login';
import Register from './pages/Register';
import SuccessPage from './pages/SuccessPage';
import { createBrowserRouter, RouterProvider, Form, redirect, useLocation } from "react-router-dom";
import Home from './pages/Home';
import UserProfile from './pages/UserProfile';
import ProductList from './pages/ProductList';
import Checkout1 from './pages/Checkout1';
import Checkout2 from './pages/Checkout2';
import ProductCatalog from './pages/ProductCatalog';
import ProductView from './pages/ProductView';
import OrderList from './pages/OrderList';
import OrderView from './pages/OrderView';

async function formRegister({ request }){

  const formData = await request.formData();
  let obj = {
    "salutation" : formData.get("salutation"),
    "firstName" : formData.get("firstName"),
    "lastName" : formData.get("lastName"),
    "age" : formData.get("age"),
    "contactNumber" : formData.get("contactNumber"),
    "email" : formData.get("email"),
    "userName" : formData.get("userName"),
    "password" : formData.get("password"),
    "passwordConfirm" : formData.get("passwordConfirm"),
    "notifyEmail" : formData.get("notifyEmail"),
    "gst" : formData.get("gst")
  }

  await fetch("http://localhost:3500/user/register", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(obj)
  })
  .then(result=>result.json())
  .then(data=>console.log(data.message))
  .catch(err=>console.error(err));
  return redirect("/");
}


// Router config
const router = createBrowserRouter([
  {
    path: "/",
    element: <Login />
  },
  {
    path: "/register",
    element: <Register />,
    action: formRegister
  },
  {
    path: "/success",
    element: <SuccessPage />,
  },
  {
    path: "/home",
    element: <Home />,
  },
  {
    path: "/userProfile",
    element: <UserProfile />,
  },
  {
    path: "/productList",
    element: <ProductList />,
  },
  {
    path: "/checkout1",
    element: <Checkout1 />,
  },
  {
    path: "/checkout2",
    element: <Checkout2 />,
  },
  {
    path: "/productCatalog",
    element: <ProductCatalog />,
  },
  {
    path: "/productView",
    element: <ProductView />,
  },
  {
    path: "/orderList",
    element: <OrderList />,
  },
  {
    path: "/orderView",
    element: <OrderView />,
  },
]);

ReactDOM.createRoot(document.getElementById("root")).render(
  <RouterProvider router={router} />
);

// jsonwebtoken