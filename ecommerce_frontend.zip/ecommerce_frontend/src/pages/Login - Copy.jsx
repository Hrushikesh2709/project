import React from "react";
import Button from "@mui/material/Button";
// import SendIcon from "@mui/icons-material/Send";
import LoginIcon from "@mui/icons-material/Login";
import TextField from "@mui/material/TextField";
import RestartAltIcon from "@mui/icons-material/RestartAlt";
import LockResetIcon from '@mui/icons-material/LockReset';
import {Form} from "react-router-dom";
import { useEffect, useState, useRef } from "react";
import ToggleDarkMode from "../components/ToggleDarkMode";

function Login(){

    const [data, setData] = useState();
    const modeBtnRef = useRef(null);
    const [toggleMode, setToggleMode] = useState(0);

    useEffect(()=>{
        fetch("http://localhost:3500/")
        .then(result => {
            if(!result.ok){
                throw new Error("Network Response Failed");
                
            }
            return result.json();
        })
        .then(data => setData(data))
        .catch(err=>console.error(err))
    }, []);

    

    useEffect(() => {

        const handlePasswordToggle = () => {
            if(toggleMode == 0){
                alert("Dark Mode");
                setToggleMode(1);
                console.log(toggleMode);
            } else if(toggleMode == 1){
                alert("Light Mode");
                setToggleMode(0);
                console.log(toggleMode);
            }
        }
        
        if(modeBtnRef.current){
            // document.getElementsByTagName("body")[0].style.backgroundColor = "black";
            // document.getElementsByTagName("body")[0].style.color = "white";
            // document.getElementsByTagName("body")[0].style.borderColor = "white";

            // modeBtnRef.current.style.backgroundColor = "Red";
            modeBtnRef.current.addEventListener("click", handlePasswordToggle)
        }

        // This return block prevents the event listener from being added each time the component is saved during active project runtime.
        return () => {
            if(modeBtnRef.current){
                modeBtnRef.current.removeEventListener("click", handlePasswordToggle)
            }
        }
    }, [toggleMode]);   // State varibale is added in this dependency array
    
    return (
        <div className="dark:bg-gray-800 dark:text-white" style={{textAlign: 'center'}} sx={{textAlign: 'center' }}>
            <h1>User Login</h1>
            {/* <Button variant="outlined" startIcon="{ <LoginIcon /> }">Login</Button>
            <Button variant="outlined" endIcon="{ <LoginIcon /> }">Login</Button> */}
            <Form method="post">
                <TextField color="secondary" sx={{ m: '0 25px', p: '10px 25px 10px 0', width: '350px' }} required id="username" label="Username" name="username" /><br/>
                <TextField color="secondary" sx={{ m: '0 25px', p: '10px 25px 10px 0', width: '350px' }} required id="password" label="Password" name="password" type="password"/><br/><br/>
                <Button type="submit" sx={{ m: '5px 20px', p: '10px 25px 10px 0', width: '250px', textAlign: 'left' }} variant="outlined"><LoginIcon sx={{ m: '0 10px 0 0'}}/>Login</Button><br/>
                <Button type="reset" sx={{ m: '5px 20px', p: '10px 25px 10px 0', width: '250px', textAlign: 'left' }} variant="outlined"><RestartAltIcon sx={{ m: '0 10px 0 0'}}/>Reset</Button><br/>
                <Button sx={{ m: '5px 20px', p: '10px 25px 10px 0', width: '250px' }} variant="outlined"><LockResetIcon sx={{ m: '0 10px 0 0'}}/>Forgot Password</Button><br />
                <Button ref={modeBtnRef} sx={{ m: '5px 20px', p: '10px 25px 10px 0', width: '250px', textAlign: 'left' }} variant="outlined"><LoginIcon sx={{ m: '0 10px 0 0'}}/>Toggle Mode</Button>
                <ToggleDarkMode/>
            </Form>
            <br/>
            <br/>
            { data ? <p>{data.message}</p> : <p>Data not found</p>}
        </div>
    );
}

export default Login;
