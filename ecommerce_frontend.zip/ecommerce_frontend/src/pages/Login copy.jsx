import React from "react";
import Button from "@mui/material/Button";
import ButtonGroup from "@mui/material/ButtonGroup";
// import SendIcon from "@mui/icons-material/Send";
import LoginIcon from "@mui/icons-material/Login";
import TextField from "@mui/material/TextField";
import RestartAltIcon from "@mui/icons-material/RestartAlt";
import LockResetIcon from '@mui/icons-material/LockReset';
import {Form, redirect, useNavigate} from "react-router-dom";
import { useEffect, useState } from "react";
import ToggleMode from "../components/ToggleMode";
import { createTheme, CssBaseline, ThemeProvider, Typography } from "@mui/material";
import OutlinedAlert from "../components/OutlinedAlert";
import SuccessAlert from "../components/SuccessAlert";

const theme = createTheme({
  colorSchemes: {
    dark: true,   // For mode toggling purpose
  }
});

function Login(){

    const [data, setData] = useState();
    const navigate = useNavigate();
    
    useEffect(()=>{
        fetch("http://localhost:3500/")
        .then(result => {
            if(!result.ok){
                throw new Error("Network Response Failed");
                
            }
            return result.json();
        })
        .then(data => setData(data))
        .catch(err=>console.error(err))
    }, []);

    
    const [successOpen, setSuccessOpen] = useState(false);
    const [successMessage, setSuccessMessage] = useState("");
    
    const handleSubmit = async (e) => {
        e.preventDefault();
        const message = "Login Successful";
        await new Promise ((resolve)=>setTimeout(resolve, 1000));
        setSuccessMessage(message);
        setSuccessOpen(true);
        setTimeout(()=>setSuccessOpen(false), 2000);
    }

    
    
    return (
        <ThemeProvider id="themeProvider" theme={theme}>
            <CssBaseline />
            
            <SuccessAlert open={successOpen} onClose={()=>setSuccessOpen(false)} message={successMessage}/>

            {/* <OutlinedAlert/> */}
            <div className="!m-5 !p-5 !ring-1 !text-center !rounded">
                {/* <h1 className="!text-2xl !font-bold !p-5">User Login</h1> */}
                <div className="!flex">
                    <Typography className="!text-2xl !font-bold !p-5">
                        User Login
                    </Typography>
                    <div className="!ml-auto">
                        <ToggleMode/>
                    </div>
                </div>
                
                <Form onSubmit={handleSubmit} method="post">
                
                    <TextField color="secondary" className="!w-80 !my-2" required id="username" label="Username" name="username" /><br/>
                    <TextField color="secondary" className="!w-80 !my-2" required id="password" label="Password" name="password" type="password"/><br/>
                    <Button type="submit" className="!my-2 !p-2 !w-80 !text-center" variant="outlined">Login<LoginIcon className="!ml-2"/></Button><br/>
                    <ButtonGroup className="!my-2 !w-80 !text-center" variant="outlined" aria-label="Basic button group">
                        <Button type="reset" className="!p-2 !w-1/2">Reset</Button>
                        <Button onClick={()=> navigate("/register")} className="!p-2 !w-1/2">Register</Button>
                    </ButtonGroup><br />
                    <Button className="!my-2 !p-2 !w-80 !text-center" variant="outlined">Forgot Password<LockResetIcon className="!ml-2"/></Button><br />
                </Form>
                <center className="!my-2">
                    { data ? <p className="!rounded !border !bg-green-500 !w-80 !p-2">{data.message}</p> : <p className="!rounded !border !bg-red-500 !w-80 !p-2">Connection not established</p>}
                </center>
            </div>
        </ThemeProvider>
    );
}

export default Login;
