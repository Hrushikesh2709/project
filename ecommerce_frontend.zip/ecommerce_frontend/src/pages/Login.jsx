import React from "react";
import Button from "@mui/material/Button";
import ButtonGroup from "@mui/material/ButtonGroup";
import LoginIcon from "@mui/icons-material/Login";
import TextField from "@mui/material/TextField";
import LockResetIcon from '@mui/icons-material/LockReset';
import {Form, useNavigate} from "react-router-dom";
import { useEffect, useState } from "react";
import ToggleMode from "../components/ToggleMode";
import { createTheme, CssBaseline, ThemeProvider, Typography } from "@mui/material";
import SuccessAlert from "../components/SuccessAlert";
import CancelAlert from "../components/CancelAlert";

const theme = createTheme({
  colorSchemes: {
    dark: true,   // For mode toggling purpose
  }
});

function Login(){

    const [data, setData] = useState();
    const navigate = useNavigate();
    
    useEffect(()=>{
        fetch("http://localhost:3500/")
        .then(result => {
            if(!result.ok){
                throw new Error("Network Response Failed");                
            }
            return result.json();
        })
        .then(data => setData(data))
        .catch(err=>console.error(err))
    }, []);

    
    const [successOpen, setSuccessOpen] = useState(false);
    const [successMessage, setSuccessMessage] = useState("");

    const [failOpen, setFailOpen] = useState(false);
    const [failMessage, setFailMessage] = useState("");

    let loginSuccess = 0;
    let loginFail = 0;

    // Form submit handker function
    const handleSubmit = async (e) => {

        e.preventDefault();
        const formData = new FormData(e.target);
        const data = Object.fromEntries(formData.entries());
        // console.log('Submitted:', data);
        await fetch("http://localhost:3500/user/login", {
            method: "POST",
            headers: {
            'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                username: data.username,
                password: data.password
            })
        })
        .then(result=>result.json())
        .then((data)=>{
            console.log(data.userName);
            if(data.success == 1){
                const date = new Date();
                // const utcDate = date.toUTCString();
                // const z = date.getUTCHours() + 1;
                // date.setUTCHours(z);
                const z = date.getUTCMinutes() + 5;
                date.setUTCMinutes(z);
                document.cookie = `user=${data.userName}; expires=${date.toUTCString()}`;
                loginSuccess = data.success;
            } else {
                loginFail = 1;
            }
        })
        .catch(err=>{
                console.error(err);
                console.log("Failed to fetch");
                navigate("/");
            }
        );
        if(loginSuccess == 1){
            loginSuccess = 0;
            const message = "Login Successful";
            await new Promise ((resolve)=>setTimeout(resolve, 500));
            setSuccessMessage(message);
            setSuccessOpen(true);
            setTimeout(()=>setSuccessOpen(false), 2000);
            setTimeout(()=>navigate("/home"), 2250);
            // return redirect("/");    // Alternate method. Here 'redirect' is imported from react-router-dom.
        } else if (loginFail == 1) {
             loginFail = 0;
            const message = "Login Failed";
            await new Promise ((resolve)=>setTimeout(resolve, 500));
            setFailMessage(message);
            setFailOpen(true);
            setTimeout(()=>setFailOpen(false), 2000);
            setTimeout(()=>navigate("/"), 2250);
        } else {
            navigate("/");
        }

    }    
    
    return (
        <ThemeProvider id="themeProvider" theme={theme}>
            <CssBaseline />
            <SuccessAlert open={successOpen} onClose={()=>setSuccessOpen(false)} message={successMessage}/>
            <CancelAlert open={failOpen} onClose={()=>setFailOpen(false)} message={failMessage}/>
                
            <div className="!m-5 !p-5 !ring-1 !text-center !rounded">
                <div className="!flex">
                    <Typography className="!text-2xl !font-bold !p-5">
                        User Login
                    </Typography>
                    <div className="!ml-auto">
                        <ToggleMode/>
                    </div>
                </div>
                
                <Form onSubmit={handleSubmit} method="post">                
                    <TextField color="secondary" className="!w-80 !my-2" required id="username" label="Username" name="username" /><br/>
                    <TextField color="secondary" className="!w-80 !my-2" required id="password" label="Password" name="password" type="password"/><br/>
                    <Button type="submit" className="!my-2 !p-2 !w-80 !text-center" variant="outlined">Login<LoginIcon className="!ml-2"/></Button><br/>
                    <ButtonGroup className="!my-2 !w-80 !text-center" variant="outlined" aria-label="Basic button group">
                        <Button type="reset" className="!p-2 !w-1/2">Reset</Button>
                        <Button onClick={()=> navigate("/register")} className="!p-2 !w-1/2">Register</Button>
                    </ButtonGroup><br />
                    <Button className="!my-2 !p-2 !w-80 !text-center" variant="outlined">Forgot Password<LockResetIcon className="!ml-2"/></Button><br />
                </Form>
                <center className="!my-2">
                    { data ? <p className="!rounded !border !bg-green-500 !w-80 !p-2">{data.message}</p> : <p className="!rounded !border !bg-red-500 !w-80 !p-2">Connection not established</p>}
                </center>
            </div>
        </ThemeProvider>
    );
}

export default Login;