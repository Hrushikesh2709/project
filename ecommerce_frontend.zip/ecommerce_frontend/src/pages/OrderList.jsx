import ToggleMode from "../components/ToggleMode";
import { createTheme, CssBaseline, ThemeProvider, Typography } from "@mui/material";
import ResponsiveNavbar from "../components/ResponsiveNavbar";

const theme = createTheme({
  colorSchemes: {
    dark: true,   // For mode toggling purpose
  }
});

function OrderList(){
    
    return (
        <ThemeProvider id="themeProvider" theme={theme}>
            <CssBaseline />
            <ResponsiveNavbar/>
            <div className="!m-5 !p-5 !ring-1 !text-center !rounded">
                <div className="!flex">
                    <Typography className="!text-2xl !font-bold !p-5">
                        Order List Page
                    </Typography>
                    <div className="!ml-auto">
                        <ToggleMode/>
                    </div>
                </div>
                <div className="!mb-5">
                    <p>This page is under development</p>
                </div>
                <center className="!my-2">
                    <p className="!w-80">@ Copyright 2025</p>
                </center>
            </div>
        </ThemeProvider>
    );
}

export default OrderList;