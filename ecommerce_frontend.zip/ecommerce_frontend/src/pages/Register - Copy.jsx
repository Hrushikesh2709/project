import React, {useEffect, useState} from "react";
import Box from '@mui/material/Box';
import RadioGroup from '@mui/material/RadioGroup';
import Radio from '@mui/material/Radio';
import {Form} from "react-router-dom";
import { TextField, MenuItem, Select, InputLabel, FormControl, Button, FormLabel, FormControlLabel } from "@mui/material";
import LoginIcon from "@mui/icons-material/Login";
import $ from "jquery";
import { ThemeProvider, createTheme, useColorScheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';

function MyApp() {
  const { mode, setMode } = useColorScheme();
  if (!mode) {
    return null;
  }
  return (
    <Box
      sx={{
        display: 'flex',
        width: '100%',
        alignItems: 'center',
        justifyContent: 'center',
        bgcolor: 'background.default',
        color: 'text.primary',
        borderRadius: 1,
        p: 3,
        minHeight: '56px',
      }}
    >
      <FormControl>
        <FormLabel id="demo-theme-toggle">Choose Theme</FormLabel>
        <RadioGroup
          aria-labelledby="demo-theme-toggle"
          name="theme-toggle"
          row
          value={mode}
          onChange={(event) =>
            setMode(event.target.value)
          }
        >
          <FormControlLabel value="light" control={<Radio />} label="Light" />
          <FormControlLabel value="dark" control={<Radio />} label="Dark" />
        </RadioGroup>
      </FormControl>
    </Box>
  );
}

const theme = createTheme({
  colorSchemes: {
    dark: true,
  },
});

function Register(){

    // useEffect(()=>{
    //     $(document).ready(function(){
    //         console.log("Jquery is working");
    //     })
    // })

    // const { mode, setMode } = useState(false);

    // const themeUpdate = () => {
    //     let theme = createTheme({
    //         colorSchemes: {
    //             dark: mode ? "light" : "dark",
    //         },
    //     });
    // }

    // useEffect(()=>{
    //     $(document).ready(()=>{
    //         themeUpdate();
    //     })
        
    // }, [mode]);


    const handleClick = () => {
        // console.log("Username Value");
        let value = $("#username").val();
        console.log("Username Value: " , value);
    }

    return (
        <ThemeProvider id="themeProvider" theme={theme}>
            <CssBaseline />
            <div style={{textAlign: 'center', border: '1px solid black', borderRadius: '5px', margin:'25px 350px'}} sx={{textAlign: 'center' }}>
                <h1>Register</h1>
                <Form method="post">
                    <FormControl sx={{ m: '0 25px', p: '10px 25px 10px 0', width: '350px' }} >
                        <InputLabel id="demo-simple-select-label">Salutation *</InputLabel>
                        <Select required name="salutation" labelId="demo-simple-select-label" id="salutation" label="Salutation">
                            <MenuItem value="">None</MenuItem>
                            <MenuItem value={"Mr"}>Mr</MenuItem>
                            <MenuItem value={"Mrs"}>Mrs</MenuItem>
                            <MenuItem value={"Ms"}>Ms</MenuItem>
                        </Select>
                    </FormControl><br/>
                    <TextField sx={{ m: '0 25px', p: '10px 25px 10px 0', width: '350px' }} required id="outlined-required" label="First Name" name="firstName"/><br/>
                    <TextField sx={{ m: '0 25px', p: '10px 25px 10px 0', width: '350px' }} required id="outlined-required" label="Last Name" name="lastName"/><br/>
                    <TextField sx={{ m: '0 25px', p: '10px 25px 10px 0', width: '350px' }} required id="outlined-required" label="Age" name="age"/><br/>
                    <TextField sx={{ m: '0 25px', p: '10px 25px 10px 0', width: '350px' }} required id="outlined-required" label="Contact Number" name="contactNumber"/><br/>
                    <TextField sx={{ m: '0 25px', p: '10px 25px 10px 0', width: '350px' }} required id="outlined-required" label="Email" name="email"/><br/>
                    <TextField sx={{ m: '0 25px', p: '10px 25px 10px 0', width: '350px' }} required id="username" label="User Name" name="userName"/><br/>
                    <TextField sx={{ m: '0 25px', p: '10px 25px 10px 0', width: '350px' }} required id="outlined-required" label="Password" name="password"/><br/>
                    <TextField sx={{ m: '0 25px', p: '10px 25px 10px 0', width: '350px' }} required id="outlined-required" label="Confirm Password" name="passwordConfirm"/><br/>
                    <TextField sx={{ m: '0 25px', p: '10px 25px 10px 0', width: '350px' }} required id="outlined-required" label="Notify Email" name="notifyEmail"/><br/>
                    <TextField sx={{ m: '0 25px', p: '10px 25px 10px 0', width: '350px' }} required id="outlined-required" label="GST Number" name="gst"/><br/>
                    <Button onClick={handleClick} sx={{ m: '5px 20px 25px', p: '10px 25px 10px 0', width: '250px', textAlign: 'left' }} variant="outlined"><LoginIcon sx={{ m: '0 10px 0 0'}}/>Show</Button><br/>
                    <Button type="submit" sx={{ m: '5px 20px 25px', p: '10px 25px 10px 0', width: '250px', textAlign: 'left' }} variant="outlined"><LoginIcon sx={{ m: '0 10px 0 0'}}/>Submit</Button><br/>
                    {/* <Button onClick={()=>{alert("Toggle");toggleMode();}} sx={{ m: '5px 20px 25px', p: '10px 25px 10px 0', width: '250px', textAlign: 'left' }} variant="outlined"><LoginIcon sx={{ m: '0 10px 0 0'}}/>Toggle Mode</Button> */}
                    
                    {/* <Button onClick={(event) =>setMode(!mode)} sx={{ m: '5px 20px 25px', p: '10px 25px 10px 0', width: '250px', textAlign: 'left' }} variant="outlined"><LoginIcon sx={{ m: '0 10px 0 0'}}/>Toggle Mode</Button><br/> */}
                    <MyApp/>
                </Form>
            </div>
        </ThemeProvider>
    
    )
}

export default Register;

        // paymentOptionId 
        // userAddressId 
        // isActive 