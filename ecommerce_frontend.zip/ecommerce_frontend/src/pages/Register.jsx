import {Form} from "react-router-dom";
import { TextField, MenuItem, Select, InputLabel, FormControl, Button, FormLabel, FormControlLabel, Typography } from "@mui/material";
import LoginIcon from "@mui/icons-material/Login";
import { ThemeProvider, createTheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import ToggleMode from "../components/ToggleMode";

// const baseTheme = createTheme();

const theme = createTheme({
  colorSchemes: {
    dark: true,   // For mode toggling purpose
  }
});


function Register(){

    return (
        <ThemeProvider id="themeProvider" theme={theme}>
            <CssBaseline />
            <div className="!m-5 p-5 !text-center !ring-1 !rounded"> 
              <div className="!flex">
                <Typography className="!text-2xl !font-bold !p-5">
                  Register
                </Typography>
                <div className="!ml-auto">
                  <ToggleMode/>
                </div>
              </div>
              <Form method="post">
                  <FormControl className="!w-80 !my-2" >
                      <InputLabel id="demo-simple-select-label">Salutation *</InputLabel>
                      <Select required name="salutation" labelId="demo-simple-select-label" id="salutation" label="Salutation">
                          <MenuItem value="">None</MenuItem>
                          <MenuItem value={"Mr"}>Mr</MenuItem>
                          <MenuItem value={"Mrs"}>Mrs</MenuItem>
                          <MenuItem value={"Ms"}>Ms</MenuItem>
                      </Select>
                  </FormControl><br/>
                  <TextField className="!w-80 !my-2" required label="First Name" name="firstName"/><br/>
                  <TextField className="!w-80 !my-2" required label="Last Name" name="lastName"/><br/>
                  <TextField className="!w-80 !my-2" required label="Age" name="age"/><br/>
                  <TextField className="!w-80 !my-2" required label="Contact Number" name="contactNumber"/><br/>
                  <TextField className="!w-80 !my-2" required label="Email" name="email"/><br/>
                  <TextField className="!w-80 !my-2" required label="User Name" name="userName"/><br/>
                  <TextField className="!w-80 !my-2" required label="Password" name="password"/><br/>
                  <TextField className="!w-80 !my-2" required label="Confirm Password" name="passwordConfirm"/><br/>
                  <TextField className="!w-80 !my-2" required label="Notify Email" name="notifyEmail"/><br/>
                  <TextField className="!w-80 !my-2" required label="GST Number" name="gst"/><br/>
                  <Button className="!my-2 !p-2 !w-80 !text-center" type="submit" variant="outlined">Submit<LoginIcon className="ml-2"/></Button><br/>
              </Form>
            </div>
        </ThemeProvider>
    );
}

export default Register;