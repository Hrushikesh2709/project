import React from 'react';
import { useLocation } from "react-router-dom";

function SuccessPage() {
    // const params = new URLSearchParams(location?.search);
    const query = new URLSearchParams(useLocation().search);
    const username = query.get("username");
    const password = query.get("password");
    return (
        <div>
            <h3>Form submitted! Hello, {username + "."} Welcome To E-commerce Website.</h3>
        </div>
    );
}

export default SuccessPage;