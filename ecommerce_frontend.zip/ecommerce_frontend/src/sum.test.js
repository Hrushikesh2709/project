const sum = require("./pages/sum");

test("adds 25 + 50 to equal 75.", ()=>{
    expect(sum(25,50)).toBe(75);
})